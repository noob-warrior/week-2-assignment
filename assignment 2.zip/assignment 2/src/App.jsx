// App is now just a shell - routing is handled in main.jsx via the hash router
function App() {
  return React.createElement("div", null, "loading...");
}

window.App = App;
