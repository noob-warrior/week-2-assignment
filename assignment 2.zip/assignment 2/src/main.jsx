// Simple hash-based router that works reliably when opening as a file://
// Reads window.location.hash to decide which page to show, and re-renders on hashchange.

const root = ReactDOM.createRoot(document.getElementById("root"));

function render() {
  const hash = window.location.hash; // e.g. "" or "#/books/lantern-keeper"
  const match = hash.match(/^#\/books\/(.+)$/);
  const bookId = match ? match[1] : null;

  const books = window.bookCatalog;
  let page;

  if (bookId) {
    page = React.createElement(window.BookDetail, { books, bookId });
  } else {
    page = React.createElement(window.BookList, { books });
  }

  root.render(
    React.createElement("main", { className: "app-shell" }, page)
  );
}

// Re-render whenever the hash changes (i.e. when the user navigates)
window.addEventListener("hashchange", render);
render();
