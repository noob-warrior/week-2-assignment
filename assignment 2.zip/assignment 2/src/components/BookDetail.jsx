function BookDetail({ books, bookId }) {
  const book = books.find((b) => b.id === bookId);

  // Use a plain <a> tag to go back - no React Router needed
  const backLink = React.createElement(
    "a",
    { className: "detail-back", href: "#/" },
    "← Back to book list"
  );

  // Show a friendly message if the book ID doesn't match anything
  if (!book) {
    return React.createElement(
      "section",
      { className: "page-section" },
      backLink,
      React.createElement(
        "div",
        { className: "detail-empty" },
        React.createElement("h2", null, "Book not found"),
        React.createElement("p", null, "The selected book could not be found in the catalog.")
      )
    );
  }

  const coverImage = book.imageUrl
    ? React.createElement("img", {
        className: "detail-cover",
        src: book.imageUrl,
        alt: `${book.title} cover`,
      })
    : React.createElement(
        "div",
        { className: "detail-cover-placeholder" },
        "No image available"
      );

  const bookInfo = React.createElement(
    "div",
    { className: "detail-copy" },
    React.createElement("p", { className: "detail-label" }, "Book Details"),
    React.createElement("h1", null, book.title),
    React.createElement("p", { className: "detail-author" }, `by ${book.author}`),
    React.createElement("p", { className: "detail-description" }, book.description)
  );

  return React.createElement(
    "section",
    { className: "page-section" },
    backLink,
    React.createElement("article", { className: "detail-card" }, coverImage, bookInfo)
  );
}

window.BookDetail = BookDetail;
