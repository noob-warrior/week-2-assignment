function BookList({ books }) {

  // Navigate to a book's detail page by updating the URL hash
  function goToBook(id) {
    window.location.hash = `/books/${id}`;
  }

  function renderBookCard(book) {
    const coverImage = book.imageUrl
      ? React.createElement("img", {
          className: "book-thumb",
          src: book.imageUrl,
          alt: `${book.title} cover`,
        })
      : React.createElement("div", { className: "thumb-placeholder" }, "NO COVER");

    // Use a plain <a> tag with a hash href - no React Router needed
    const bookLink = React.createElement(
      "a",
      { className: "card-link", href: `#/books/${book.id}` },
      book.title
    );

    const cardBody = React.createElement(
      "div",
      { className: "book-copy" },
      React.createElement("h2", null, bookLink),
      React.createElement("p", { className: "card-author" }, `by ${book.author}`),
      React.createElement("p", { className: "card-summary" }, book.shortDescription),
      React.createElement(
        "button",
        {
          type: "button",
          className: "card-button",
          onClick: () => goToBook(book.id),
        },
        "Read More"
      )
    );

    return React.createElement(
      "article",
      { className: "book-card", key: book.id },
      coverImage,
      cardBody
    );
  }

  const pageHeader = React.createElement(
    "header",
    { className: "page-header" },
    React.createElement("h1", null, "Book Explorer"),
    React.createElement(
      "p",
      null,
      "Browse the small catalog below and click any title to open the full book details page."
    )
  );

  const bookGrid = React.createElement(
    "div",
    { className: "book-grid" },
    books.map(renderBookCard)
  );

  return React.createElement("section", { className: "page-section" }, pageHeader, bookGrid);
}

window.BookList = BookList;
