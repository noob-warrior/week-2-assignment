const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = 3000;
const ROOT = __dirname;

const MIME_TYPES = {
  ".css": "text/css",
  ".html": "text/html",
  ".js": "text/javascript",
  ".jsx": "text/javascript",
  ".svg": "image/svg+xml",
};

// Read a file from disk and send it as an HTTP response
function serveFile(filePath, res) {
  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || "application/octet-stream";

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(500, { "Content-Type": "text/plain" });
      res.end("Something went wrong while loading the file.");
      return;
    }

    res.writeHead(200, { "Content-Type": contentType });
    res.end(data);
  });
}

http
  .createServer((req, res) => {
    // Strip query strings and decode encoded characters (e.g. spaces in paths)
    const rawPath = decodeURIComponent((req.url || "/").split("?")[0]);
    const relativePath =
      rawPath === "/" ? "index.html" : rawPath.replace(/^[/\\]+/, "");

    // Prevent path traversal attacks (e.g. ../../etc/passwd)
    const safePath = path.normalize(relativePath).replace(/^(\.\.[/\\])+/, "");
    const filePath = path.join(ROOT, safePath);

    fs.stat(filePath, (err, stats) => {
      if (!err && stats.isFile()) {
        serveFile(filePath, res);
      } else {
        // Fall back to index.html so client-side routing works
        serveFile(path.join(ROOT, "index.html"), res);
      }
    });
  })
  .listen(PORT, () => {
    console.log(`Book Explorer is running at http://localhost:${PORT}`);
  });
